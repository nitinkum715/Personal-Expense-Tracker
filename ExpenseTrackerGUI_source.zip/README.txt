Personal Expense Tracker - GUI version
--------------------------------------
Run: copy ExpenseTrackerGUI.exe into the folder that has your transactions.txt / budget.txt
(next to tracker.exe) and double-click it. It reads and writes the SAME files as the console version.

Rebuild from source: double-click build.bat (needs MinGW g++ and windres on PATH).

Files
  main_gui.cpp   window + buttons (Win32 API, no extra libraries)
  TrackerCore.h  your Tracker logic without cin/cout
  Transaction.h, Income.h, Expense.h   your original classes, unchanged
  app.rc, app.manifest   modern look + sharp text on high-DPI screens
