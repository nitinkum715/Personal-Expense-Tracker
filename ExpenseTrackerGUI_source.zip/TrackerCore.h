// TrackerCore.h
// GUI-friendly version of your Tracker class.
// Same logic and SAME FILE FORMAT (transactions.txt / budget.txt), but it
// never uses cin/cout - it just returns values so a window can show them.

#ifndef TRACKERCORE_H
#define TRACKERCORE_H

#include "Income.h"
#include "Expense.h"

#include <vector>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cctype>
#include <cstdio>
#include <algorithm>

using namespace std;

class TrackerCore {

private:

    vector<Transaction*> transactions;
    map<string, double> monthlyBudgets;
    int nextId = 1;

    string transactionsPath;
    string budgetPath;

    // ---------- file handling ----------
    bool saveTransactions() {

        ofstream file(transactionsPath.c_str());
        if (!file) return false;

        for (Transaction* t : transactions) {
            file << t->getId() << "|"
                 << t->getType() << "|"
                 << fixed << setprecision(2) << t->getAmount() << "|"
                 << t->getCategory() << "|"
                 << t->getDate() << "\n";
        }
        return file.good();
    }

    void loadTransactions() {

        ifstream file(transactionsPath.c_str());
        if (!file) return;

        string line;
        while (getline(file, line)) {

            if (!line.empty() && line[line.size() - 1] == '\r')
                line.erase(line.size() - 1);
            if (line.empty()) continue;

            stringstream ss(line);
            string idStr, type, amountStr, category, date;

            getline(ss, idStr, '|');
            getline(ss, type, '|');
            getline(ss, amountStr, '|');
            getline(ss, category, '|');
            getline(ss, date);

            try {
                int id = stoi(idStr);
                double amount = stod(amountStr);
                if (amount <= 0) continue;

                if (type == "INCOME")
                    transactions.push_back(new Income(id, amount, category, date));
                else if (type == "EXPENSE")
                    transactions.push_back(new Expense(id, amount, category, date));
                else
                    continue;

                if (id >= nextId) nextId = id + 1;
            }
            catch (const exception&) {
                // bad line - skip it
            }
        }
    }

    bool saveBudgets() {

        ofstream file(budgetPath.c_str());
        if (!file) return false;

        for (const auto& b : monthlyBudgets)
            file << b.first << "|" << fixed << setprecision(2) << b.second << "\n";

        return file.good();
    }

    void loadBudgets() {

        ifstream file(budgetPath.c_str());
        if (!file) return;

        string line;
        while (getline(file, line)) {

            if (!line.empty() && line[line.size() - 1] == '\r')
                line.erase(line.size() - 1);

            stringstream ss(line);
            string monthYear, amountStr;
            getline(ss, monthYear, '|');
            getline(ss, amountStr);

            try {
                double amount = stod(amountStr);
                if (!monthYear.empty() && amount > 0)
                    monthlyBudgets[monthYear] = amount;
            }
            catch (const exception&) {
            }
        }
    }

    static string makeMonthKey(int month, int year) {
        return string(month < 10 ? "0" : "") + to_string(month) + "-" + to_string(year);
    }

public:

    // dir must end with a slash/backslash (or be empty for current folder)
    explicit TrackerCore(const string& dir = "")
        : transactionsPath(dir + "transactions.txt"),
          budgetPath(dir + "budget.txt") {
        loadTransactions();
        loadBudgets();
    }

    TrackerCore(const TrackerCore&) = delete;
    TrackerCore& operator=(const TrackerCore&) = delete;

    ~TrackerCore() {
        for (Transaction* t : transactions) delete t;
    }

    // ---------- helpers ----------
    static string trim(const string& s) {
        size_t a = s.find_first_not_of(" \t\r\n");
        if (a == string::npos) return "";
        size_t b = s.find_last_not_of(" \t\r\n");
        return s.substr(a, b - a + 1);
    }

    static string lower(string s) {
        for (char& c : s) c = (char)tolower((unsigned char)c);
        return s;
    }

    // "DD-MM-YYYY" -> numbers. Returns false if not a real calendar date.
    static bool parseDate(const string& s, int& d, int& m, int& y) {

        if (s.size() != 10 || s[2] != '-' || s[5] != '-') return false;

        const int digitPos[] = {0, 1, 3, 4, 6, 7, 8, 9};
        for (int i : digitPos)
            if (!isdigit((unsigned char)s[i])) return false;

        d = stoi(s.substr(0, 2));
        m = stoi(s.substr(3, 2));
        y = stoi(s.substr(6, 4));

        if (m < 1 || m > 12 || y < 1 || d < 1) return false;

        static const int dim[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        int maxDay = dim[m - 1];
        bool leap = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
        if (m == 2 && leap) maxDay = 29;

        return d <= maxDay;
    }

    // ---------- data access ----------
    const vector<Transaction*>& all() const { return transactions; }

    // Add Income / Expense. Returns false and fills err on problems.
    bool addTransaction(bool isIncome, double amount, string category,
                        const string& date, string& err) {

        category = trim(category);
        for (char& c : category) if (c == '|') c = '-';   // '|' is our separator

        int d, m, y;
        if (!(amount > 0))               { err = "Amount must be greater than zero.";           return false; }
        if (category.empty())            { err = "Please enter a category.";                     return false; }
        if (category.size() > 40)        { err = "Category is too long (max 40 characters).";   return false; }
        if (!parseDate(date, d, m, y))   { err = "Date must be a valid DD-MM-YYYY date.";        return false; }

        if (isIncome)
            transactions.push_back(new Income(nextId++, amount, category, date));
        else
            transactions.push_back(new Expense(nextId++, amount, category, date));

        if (!saveTransactions()) {
            delete transactions.back();
            transactions.pop_back();
            nextId--;
            err = "Could not save transactions.txt (is the folder read-only?).";
            return false;
        }
        return true;
    }

    // Delete by ID. Returns false if the ID does not exist.
    bool removeTransaction(int id) {

        for (auto it = transactions.begin(); it != transactions.end(); ++it) {
            if ((*it)->getId() == id) {
                delete *it;
                transactions.erase(it);
                saveTransactions();
                return true;
            }
        }
        return false;
    }

    double totalIncome() const {
        double total = 0;
        for (Transaction* t : transactions)
            if (t->getType() == "INCOME") total += t->getAmount();
        return total;
    }

    double totalExpenses() const {
        double total = 0;
        for (Transaction* t : transactions)
            if (t->getType() == "EXPENSE") total += t->getAmount();
        return total;
    }

    double balance() const { return totalIncome() - totalExpenses(); }

    // Total expenses of one month, optionally with category-wise totals.
    double monthlyExpenses(int month, int year,
                           map<string, double>* categoryTotals = nullptr,
                           int* transactionCount = nullptr) const {

        double total = 0;
        int count = 0;

        for (Transaction* t : transactions) {

            if (t->getType() != "EXPENSE") continue;

            int d, m, y;
            if (!parseDate(t->getDate(), d, m, y)) continue;

            if (m == month && y == year) {
                total += t->getAmount();
                count++;
                if (categoryTotals) (*categoryTotals)[t->getCategory()] += t->getAmount();
            }
        }

        if (transactionCount) *transactionCount = count;
        return total;
    }

    // ---------- budgets ----------
    bool setBudget(int month, int year, double amount) {
        monthlyBudgets[makeMonthKey(month, year)] = amount;
        return saveBudgets();
    }

    bool getBudget(int month, int year, double& amount) const {
        auto it = monthlyBudgets.find(makeMonthKey(month, year));
        if (it == monthlyBudgets.end()) return false;
        amount = it->second;
        return true;
    }
};

#endif
