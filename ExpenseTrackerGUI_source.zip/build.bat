@echo off
REM Rebuild the GUI with MinGW g++ (same compiler you used for tracker.exe)
windres app.rc -O coff -o app.res
g++ -std=c++14 -O2 -mwindows -static -static-libgcc -static-libstdc++ main_gui.cpp app.res -o ExpenseTrackerGUI.exe -lcomctl32 -luxtheme -lgdi32
if %errorlevel%==0 (echo Build OK: ExpenseTrackerGUI.exe) else (echo Build failed)
pause
