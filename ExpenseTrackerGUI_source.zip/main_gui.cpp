// main_gui.cpp  -  Personal Expense Tracker (Windows desktop GUI)
// Pure Win32 API: no extra libraries to install, just a C++ compiler (MinGW g++).
// Uses your Transaction / Income / Expense classes through TrackerCore.h.

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define WINVER 0x0601
#define _WIN32_WINNT 0x0601
#define _WIN32_IE 0x0600

#include <windows.h>
#include <commctrl.h>
#include <uxtheme.h>
#include <cstdio>
#include <cstdlib>
#include "TrackerCore.h"

// ------------------------------------------------------------------ IDs
enum {
    IDC_TITLE = 100,
    IDC_CARD_INC_C, IDC_CARD_INC_V, IDC_CARD_EXP_C, IDC_CARD_EXP_V, IDC_CARD_BAL_C, IDC_CARD_BAL_V,
    IDC_GRP_ADD, IDC_LBL_TYPE, IDC_TYPE, IDC_LBL_AMT, IDC_AMOUNT, IDC_LBL_CAT, IDC_CATEGORY,
    IDC_LBL_DATE, IDC_DATE, IDC_ADD,
    IDC_GRP_BUD, IDC_LBL_MONTH, IDC_MONTH, IDC_LBL_YEAR, IDC_YEAR, IDC_SPIN,
    IDC_LBL_BUD, IDC_BUDGET, IDC_SETBUD, IDC_PROGRESS, IDC_BUDSTATUS,
    IDC_LBL_SEARCH, IDC_SEARCH, IDC_BTN_SEARCH, IDC_BTN_ALL, IDC_BTN_DELETE, IDC_LIST,
    IDC_GRP_REPORT, IDC_REPORT, IDC_STATUS
};

// ------------------------------------------------------------------ globals
static HINSTANCE hInst;
static HWND hMain, hStatus;
static HWND hTitle, hCardC[3], hCardV[3];
static HWND hGrpAdd, hLblType, hType, hLblAmt, hAmount, hLblCat, hCategory, hLblDate, hDate, hAdd;
static HWND hGrpBud, hLblMonth, hMonth, hLblYear, hYear, hSpin, hLblBud, hBudget, hSetBud, hProgress, hBudStatus;
static HWND hLblSearch, hSearch, hBtnSearch, hBtnAll, hBtnDelete, hList;
static HWND hGrpReport, hReport;

static TrackerCore* core = nullptr;
static int dpi = 96;
static bool ready = false;
static int budgetState = 0;          // 0 none, 1 ok, 2 >=80%, 3 exceeded
static double gBalance = 0;
static RECT cardRect[3];

static HFONT fNormal, fBold, fTitle, fBig, fMono;
static HBRUSH brBg, brWhite;

static const COLORREF COL_BG     = RGB(243, 245, 249);
static const COLORREF COL_TEXT   = RGB(31, 41, 55);
static const COLORREF COL_MUTED  = RGB(107, 114, 128);
static const COLORREF COL_GREEN  = RGB(22, 163, 74);
static const COLORREF COL_RED    = RGB(220, 38, 38);
static const COLORREF COL_BLUE   = RGB(37, 99, 235);
static const COLORREF COL_ORANGE = RGB(217, 119, 6);

static const char* MONTHS[12] = {"January", "February", "March", "April", "May", "June", "July",
                                 "August", "September", "October", "November", "December"};

static int S(int v) { return MulDiv(v, dpi, 96); }

// ------------------------------------------------------------------ small helpers
static string getText(HWND h) {
    int n = GetWindowTextLengthA(h);
    string s(n + 1, '\0');
    GetWindowTextA(h, &s[0], n + 1);
    s.resize(n);
    return s;
}

// 1234567.5 -> "Rs. 12,34,567.50"  (Indian digit grouping)
static string money(double v) {
    bool neg = v < 0;
    if (neg) v = -v;
    char buf[64];
    snprintf(buf, sizeof buf, "%.2f", v);
    string s(buf);
    size_t dot = s.find('.');
    string ip = s.substr(0, dot), fp = s.substr(dot), out;
    int n = (int)ip.size();
    if (n > 3) {
        string last3 = ip.substr(n - 3), rest = ip.substr(0, n - 3), g;
        int c = 0;
        for (int i = (int)rest.size() - 1; i >= 0; i--) {
            g.insert(g.begin(), rest[i]);
            if (++c % 2 == 0 && i > 0) g.insert(g.begin(), ',');
        }
        out = g + "," + last3;
    } else out = ip;
    return string(neg ? "-" : "") + "Rs. " + out + fp;
}

static bool parseAmount(string a, double& out) {
    string clean;
    for (char c : a) if (c != ',' && c != ' ') clean += c;
    if (clean.empty()) return false;
    char* end = nullptr;
    out = strtod(clean.c_str(), &end);
    return *end == '\0' && out > 0 && out < 1e12;
}

static void setStatus(const string& s) {
    SendMessageA(hStatus, SB_SETTEXTA, 0, (LPARAM)s.c_str());
}

static HFONT mkFont(int pt, int weight, const char* face = "Segoe UI") {
    return CreateFontA(-MulDiv(pt, dpi, 72), 0, 0, 0, weight, 0, 0, 0, DEFAULT_CHARSET,
                       OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                       DEFAULT_PITCH | FF_DONTCARE, face);
}

static HWND mk(const char* cls, const char* text, DWORD style, int id, DWORD ex = 0) {
    return CreateWindowExA(ex, cls, text, WS_CHILD | WS_VISIBLE | style, 0, 0, 10, 10,
                           hMain, (HMENU)(INT_PTR)id, hInst, nullptr);
}

static void place(HWND h, int x, int y, int w, int ht) { MoveWindow(h, x, y, w, ht, TRUE); }

static int selMonth() {
    int i = (int)SendMessage(hMonth, CB_GETCURSEL, 0, 0);
    return i < 0 ? 1 : i + 1;
}

static bool selYear(int& year) {
    BOOL ok = FALSE;
    year = (int)GetDlgItemInt(hMain, IDC_YEAR, &ok, FALSE);
    return ok && year >= 1;
}

// ------------------------------------------------------------------ refreshing the screen
static void refreshSummary() {
    double inc = core->totalIncome(), exp = core->totalExpenses();
    gBalance = inc - exp;
    SetWindowTextA(hCardV[0], money(inc).c_str());
    SetWindowTextA(hCardV[1], money(exp).c_str());
    SetWindowTextA(hCardV[2], money(gBalance).c_str());
    InvalidateRect(hCardV[2], nullptr, TRUE);
}

static void refreshList() {
    string filter = TrackerCore::lower(TrackerCore::trim(getText(hSearch)));

    SendMessage(hList, WM_SETREDRAW, FALSE, 0);
    ListView_DeleteAllItems(hList);

    const vector<Transaction*>& v = core->all();
    int row = 0;

    for (int i = (int)v.size() - 1; i >= 0; i--) {          // newest first
        Transaction* t = v[i];
        if (!filter.empty() && TrackerCore::lower(t->getCategory()).find(filter) == string::npos)
            continue;

        string idStr = to_string(t->getId());
        LVITEMA it;
        memset(&it, 0, sizeof it);
        it.mask = LVIF_TEXT | LVIF_PARAM;
        it.iItem = row;
        it.pszText = (char*)idStr.c_str();
        it.lParam = (LPARAM)t;
        SendMessageA(hList, LVM_INSERTITEMA, 0, (LPARAM)&it);

        string type = t->getType() == "INCOME" ? "Income" : "Expense";
        string amt = money(t->getAmount());
        string cat = t->getCategory(), date = t->getDate();
        ListView_SetItemText(hList, row, 1, (char*)date.c_str());
        ListView_SetItemText(hList, row, 2, (char*)type.c_str());
        ListView_SetItemText(hList, row, 3, (char*)cat.c_str());
        ListView_SetItemText(hList, row, 4, (char*)amt.c_str());
        row++;
    }

    SendMessage(hList, WM_SETREDRAW, TRUE, 0);
    InvalidateRect(hList, nullptr, TRUE);

    if (!filter.empty())
        setStatus(to_string(row) + " transaction(s) match \"" + TrackerCore::trim(getText(hSearch)) + "\"");
}

static void refreshBudget(bool fillBudgetBox) {
    int month = selMonth(), year;
    if (!selYear(year)) {
        SetWindowTextA(hBudStatus, "Enter a valid year.");
        SetWindowTextA(hReport, "");
        return;
    }

    double budget = 0;
    bool has = core->getBudget(month, year, budget);

    map<string, double> cats;
    int count = 0;
    double spent = core->monthlyExpenses(month, year, &cats, &count);

    if (fillBudgetBox) {
        char b[64] = "";
        if (has) snprintf(b, sizeof b, "%.2f", budget);
        SetWindowTextA(hBudget, b);
    }

    // ---- budget status ----
    string txt;
    int pctInt = 0;
    if (!has) {
        budgetState = 0;
        txt = "No budget set for this month.\r\n\r\nType an amount above and\r\nclick \"Set Budget\".";
    } else {
        double remaining = budget - spent;
        double pct = spent / budget * 100.0;
        pctInt = pct > 100 ? 100 : (int)pct;
        char p[32];
        snprintf(p, sizeof p, "%.1f%%", pct);

        txt = "Budget:     " + money(budget) + "\r\n" +
              "Spent:      " + money(spent) + "\r\n" +
              (remaining >= 0 ? "Remaining:  " + money(remaining)
                              : "Over by:    " + money(-remaining)) + "\r\n" +
              "Used:       " + p + "\r\n\r\n";

        if (pct >= 100)      { budgetState = 3; txt += "WARNING: Monthly budget exceeded!"; }
        else if (pct >= 80)  { budgetState = 2; txt += "WARNING: 80% or more of budget used!"; }
        else                 { budgetState = 1; txt += "You are within your monthly budget."; }
    }
    SetWindowTextA(hBudStatus, txt.c_str());
    InvalidateRect(hBudStatus, nullptr, TRUE);

    COLORREF bar = budgetState == 3 ? COL_RED : budgetState == 2 ? COL_ORANGE : COL_GREEN;
    SendMessage(hProgress, PBM_SETBARCOLOR, 0, bar);
    SendMessage(hProgress, PBM_SETPOS, pctInt, 0);

    // ---- monthly report ----
    char title[96];
    snprintf(title, sizeof title, " Expense Report - %s %d ", MONTHS[month - 1], year);
    SetWindowTextA(hGrpReport, title);

    string rep;
    if (count == 0) {
        rep = "No expenses recorded for this month.";
    } else {
        char line[160];
        for (const auto& c : cats) {
            snprintf(line, sizeof line, "%-26.26s %18s\r\n", c.first.c_str(), money(c.second).c_str());
            rep += line;
        }
        rep += string(45, '-') + "\r\n";
        snprintf(line, sizeof line, "%-26s %18s\r\n", "TOTAL", money(spent).c_str());
        rep += line;
        snprintf(line, sizeof line, "(%d transaction%s)", count, count == 1 ? "" : "s");
        rep += line;
    }
    SetWindowTextA(hReport, rep.c_str());
}

static void refreshAll() {
    refreshSummary();
    refreshList();
    refreshBudget(false);
}

// ------------------------------------------------------------------ actions
static void onAdd() {
    bool isIncome = SendMessage(hType, CB_GETCURSEL, 0, 0) == 0;

    double amount;
    if (!parseAmount(getText(hAmount), amount)) {
        MessageBoxA(hMain, "Please enter a valid amount greater than zero.", "Invalid amount",
                    MB_OK | MB_ICONWARNING);
        SetFocus(hAmount);
        return;
    }

    SYSTEMTIME st;
    DateTime_GetSystemtime(hDate, &st);
    char date[16];
    snprintf(date, sizeof date, "%02d-%02d-%04d", st.wDay, st.wMonth, st.wYear);

    string category = getText(hCategory), err;
    if (!core->addTransaction(isIncome, amount, category, date, err)) {
        MessageBoxA(hMain, err.c_str(), "Cannot add transaction", MB_OK | MB_ICONWARNING);
        SetFocus(hCategory);
        return;
    }

    string msg = string(isIncome ? "Income" : "Expense") + " of " + money(amount) + " added (" +
                 TrackerCore::trim(category) + ").";

    // budget warning, like your console version
    if (!isIncome) {
        double budget;
        if (core->getBudget(st.wMonth, st.wYear, budget)) {
            double spent = core->monthlyExpenses(st.wMonth, st.wYear);
            if (spent >= budget)              msg += "   WARNING: monthly budget exceeded!";
            else if (spent >= budget * 0.8)   msg += "   WARNING: 80% of monthly budget used.";
        }
    }

    SetWindowTextA(hAmount, "");
    SetWindowTextA(hCategory, "");
    refreshAll();
    setStatus(msg);
    SetFocus(hAmount);
}

static void onSetBudget() {
    int year;
    if (!selYear(year)) {
        MessageBoxA(hMain, "Please enter a valid year.", "Invalid year", MB_OK | MB_ICONWARNING);
        return;
    }
    double amount;
    if (!parseAmount(getText(hBudget), amount)) {
        MessageBoxA(hMain, "Please enter a valid budget greater than zero.", "Invalid budget",
                    MB_OK | MB_ICONWARNING);
        SetFocus(hBudget);
        return;
    }
    int month = selMonth();
    if (!core->setBudget(month, year, amount)) {
        MessageBoxA(hMain, "Could not save budget.txt (is the folder read-only?).", "Save error",
                    MB_OK | MB_ICONERROR);
        return;
    }
    refreshBudget(false);
    setStatus(string("Budget for ") + MONTHS[month - 1] + " " + to_string(year) + " set to " + money(amount) + ".");
}

static void onDelete() {
    int sel = ListView_GetNextItem(hList, -1, LVNI_SELECTED);
    if (sel < 0) {
        MessageBoxA(hMain, "Select a transaction in the list first.", "Delete", MB_OK | MB_ICONINFORMATION);
        return;
    }

    LVITEMA it;
    memset(&it, 0, sizeof it);
    it.mask = LVIF_PARAM;
    it.iItem = sel;
    SendMessageA(hList, LVM_GETITEMA, 0, (LPARAM)&it);
    Transaction* t = (Transaction*)it.lParam;

    int id = t->getId();
    string q = "Delete transaction #" + to_string(id) + "?\n\n" +
               (t->getType() == "INCOME" ? "Income" : "Expense") + "  " + money(t->getAmount()) + "\n" +
               t->getCategory() + "  -  " + t->getDate();

    if (MessageBoxA(hMain, q.c_str(), "Confirm delete", MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES)
        return;

    core->removeTransaction(id);          // 't' is invalid after this
    refreshAll();
    setStatus("Transaction #" + to_string(id) + " deleted.");
}

// ------------------------------------------------------------------ layout
static void layout(int W, int H) {
    int m = S(14);

    place(hTitle, m, S(10), W - 2 * m, S(34));

    // summary cards
    int cardTop = S(52), cardH = S(72), gap = S(12);
    int cardW = (W - 2 * m - 2 * gap) / 3;
    for (int i = 0; i < 3; i++) {
        int x = m + i * (cardW + gap);
        SetRect(&cardRect[i], x, cardTop, x + cardW, cardTop + cardH);
        place(hCardC[i], x + S(16), cardTop + S(8), cardW - S(24), S(18));
        place(hCardV[i], x + S(16), cardTop + S(28), cardW - S(24), S(34));
    }

    int bodyTop = cardTop + cardH + S(14);
    int leftW = S(310);

    // ---- add transaction ----
    int addH = S(268);
    place(hGrpAdd, m, bodyTop, leftW, addH);
    int x0 = m + S(14), w = leftW - S(28), y = bodyTop + S(26);
    place(hLblType, x0, y, w, S(16));            place(hType, x0, y + S(18), w, S(120));
    y += S(50);
    place(hLblAmt, x0, y, w, S(16));             place(hAmount, x0, y + S(18), w, S(26));
    y += S(50);
    place(hLblCat, x0, y, w, S(16));             place(hCategory, x0, y + S(18), w, S(220));
    y += S(50);
    place(hLblDate, x0, y, w, S(16));            place(hDate, x0, y + S(18), w, S(26));
    y += S(50);
    place(hAdd, x0, y + S(2), w, S(34));

    // ---- budget ----
    int budTop = bodyTop + addH + S(10);
    int budH = H - budTop - m;
    place(hGrpBud, m, budTop, leftW, budH);
    y = budTop + S(26);
    int monthW = (int)(w * 0.56), yearW = w - monthW - S(10);
    place(hLblMonth, x0, y, monthW, S(16));      place(hMonth, x0, y + S(18), monthW, S(260));
    place(hLblYear, x0 + monthW + S(10), y, yearW, S(16));
    place(hYear, x0 + monthW + S(10), y + S(18), yearW, S(26));
    SendMessage(hSpin, UDM_SETBUDDY, (WPARAM)hYear, 0);
    y += S(50);
    place(hLblBud, x0, y, w, S(16));
    int btnW = S(96);
    place(hBudget, x0, y + S(18), w - btnW - S(8), S(26));
    place(hSetBud, x0 + w - btnW, y + S(17), btnW, S(28));
    y += S(54);
    place(hProgress, x0, y, w, S(14));
    y += S(22);
    place(hBudStatus, x0, y, w, budTop + budH - y - S(8));

    // ---- right side ----
    int rx = m + leftW + S(14), rw = W - rx - m;
    y = bodyTop;
    place(hLblSearch, rx, y + S(5), S(104), S(18));
    place(hSearch, rx + S(106), y, S(170), S(26));
    place(hBtnSearch, rx + S(286), y - S(1), S(76), S(28));
    place(hBtnAll, rx + S(368), y - S(1), S(84), S(28));
    place(hBtnDelete, rx + rw - S(150), y - S(1), S(150), S(28));

    int reportH = S(190);
    int listTop = bodyTop + S(40);
    int listH = H - m - reportH - S(10) - listTop;
    place(hList, rx, listTop, rw, listH);

    int fixedCols = S(60) + S(100) + S(90) + S(130) + GetSystemMetrics(SM_CXVSCROLL) + S(6);
    ListView_SetColumnWidth(hList, 3, rw > fixedCols + S(120) ? rw - fixedCols : S(120));

    place(hGrpReport, rx, H - m - reportH, rw, reportH);
    place(hReport, rx + S(10), H - m - reportH + S(24), rw - S(20), reportH - S(34));
}

// ------------------------------------------------------------------ creating controls
static BOOL CALLBACK setFontProc(HWND h, LPARAM lp) {
    SendMessage(h, WM_SETFONT, (WPARAM)lp, TRUE);
    return TRUE;
}

static void createControls() {

    hTitle = mk("STATIC", "Personal Expense Tracker", SS_LEFT, IDC_TITLE);

    const char* caps[3] = {"TOTAL INCOME", "TOTAL EXPENSES", "REMAINING BALANCE"};
    int capIds[3] = {IDC_CARD_INC_C, IDC_CARD_EXP_C, IDC_CARD_BAL_C};
    int valIds[3] = {IDC_CARD_INC_V, IDC_CARD_EXP_V, IDC_CARD_BAL_V};
    for (int i = 0; i < 3; i++) {
        hCardC[i] = mk("STATIC", caps[i], SS_LEFT, capIds[i]);
        hCardV[i] = mk("STATIC", "Rs. 0.00", SS_LEFT, valIds[i]);
    }

    // add transaction
    hGrpAdd = mk("BUTTON", "Add Transaction", BS_GROUPBOX, IDC_GRP_ADD);
    hLblType = mk("STATIC", "Type", SS_LEFT, IDC_LBL_TYPE);
    hType = mk("COMBOBOX", "", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, IDC_TYPE);
    SendMessageA(hType, CB_ADDSTRING, 0, (LPARAM)"Income");
    SendMessageA(hType, CB_ADDSTRING, 0, (LPARAM)"Expense");
    SendMessage(hType, CB_SETCURSEL, 1, 0);

    hLblAmt = mk("STATIC", "Amount (Rs.)", SS_LEFT, IDC_LBL_AMT);
    hAmount = mk("EDIT", "", ES_AUTOHSCROLL | WS_TABSTOP, IDC_AMOUNT, WS_EX_CLIENTEDGE);

    hLblCat = mk("STATIC", "Category", SS_LEFT, IDC_LBL_CAT);
    hCategory = mk("COMBOBOX", "", CBS_DROPDOWN | CBS_AUTOHSCROLL | WS_TABSTOP | WS_VSCROLL, IDC_CATEGORY);
    const char* cats[] = {"Salary", "Food", "Travel", "Rent", "Shopping", "Bills", "Education",
                          "Health", "Entertainment", "Savings", "Other"};
    for (const char* c : cats) SendMessageA(hCategory, CB_ADDSTRING, 0, (LPARAM)c);

    hLblDate = mk("STATIC", "Date", SS_LEFT, IDC_LBL_DATE);
    hDate = mk(DATETIMEPICK_CLASSA, "", DTS_SHORTDATEFORMAT | WS_TABSTOP, IDC_DATE);
    SendMessageA(hDate, DTM_SETFORMATA, 0, (LPARAM)"dd-MM-yyyy");

    hAdd = mk("BUTTON", "Add Transaction", BS_PUSHBUTTON | WS_TABSTOP, IDC_ADD);

    // budget
    hGrpBud = mk("BUTTON", "Monthly Budget", BS_GROUPBOX, IDC_GRP_BUD);
    hLblMonth = mk("STATIC", "Month", SS_LEFT, IDC_LBL_MONTH);
    hMonth = mk("COMBOBOX", "", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, IDC_MONTH);
    for (const char* mn : MONTHS) SendMessageA(hMonth, CB_ADDSTRING, 0, (LPARAM)mn);
    hLblYear = mk("STATIC", "Year", SS_LEFT, IDC_LBL_YEAR);
    hYear = mk("EDIT", "", ES_AUTOHSCROLL | ES_NUMBER | WS_TABSTOP, IDC_YEAR, WS_EX_CLIENTEDGE);
    hSpin = CreateWindowExA(0, UPDOWN_CLASSA, nullptr,
                            WS_CHILD | WS_VISIBLE | UDS_SETBUDDYINT | UDS_ALIGNRIGHT | UDS_ARROWKEYS | UDS_NOTHOUSANDS,
                            0, 0, 0, 0, hMain, (HMENU)(INT_PTR)IDC_SPIN, hInst, nullptr);
    SendMessage(hSpin, UDM_SETRANGE32, 2000, 2100);

    hLblBud = mk("STATIC", "Budget for this month (Rs.)", SS_LEFT, IDC_LBL_BUD);
    hBudget = mk("EDIT", "", ES_AUTOHSCROLL | WS_TABSTOP, IDC_BUDGET, WS_EX_CLIENTEDGE);
    hSetBud = mk("BUTTON", "Set Budget", BS_PUSHBUTTON | WS_TABSTOP, IDC_SETBUD);
    hProgress = mk(PROGRESS_CLASSA, "", PBS_SMOOTH, IDC_PROGRESS);
    SetWindowTheme(hProgress, L"", L"");                 // allow custom bar colours
    SendMessage(hProgress, PBM_SETRANGE32, 0, 100);
    SendMessage(hProgress, PBM_SETBKCOLOR, 0, RGB(222, 226, 233));
    hBudStatus = mk("STATIC", "", SS_LEFT, IDC_BUDSTATUS);

    // search + list
    hLblSearch = mk("STATIC", "Search category:", SS_LEFT, IDC_LBL_SEARCH);
    hSearch = mk("EDIT", "", ES_AUTOHSCROLL | WS_TABSTOP, IDC_SEARCH, WS_EX_CLIENTEDGE);
    hBtnSearch = mk("BUTTON", "Search", BS_PUSHBUTTON | WS_TABSTOP, IDC_BTN_SEARCH);
    hBtnAll = mk("BUTTON", "Show All", BS_PUSHBUTTON | WS_TABSTOP, IDC_BTN_ALL);
    hBtnDelete = mk("BUTTON", "Delete Selected", BS_PUSHBUTTON | WS_TABSTOP, IDC_BTN_DELETE);

    hList = mk(WC_LISTVIEWA, "", LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS | WS_TABSTOP,
               IDC_LIST, WS_EX_CLIENTEDGE);
    ListView_SetExtendedListViewStyle(hList, LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER | LVS_EX_LABELTIP);
    const char* colNames[5] = {"ID", "Date", "Type", "Category", "Amount"};
    int colW[5] = {S(60), S(100), S(90), S(130), S(130)};
    for (int i = 0; i < 5; i++) {
        LVCOLUMNA c;
        memset(&c, 0, sizeof c);
        c.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_FMT;
        c.fmt = (i == 4) ? LVCFMT_RIGHT : LVCFMT_LEFT;
        c.cx = colW[i];
        c.pszText = (char*)colNames[i];
        SendMessageA(hList, LVM_INSERTCOLUMNA, i, (LPARAM)&c);
    }

    hGrpReport = mk("BUTTON", " Expense Report ", BS_GROUPBOX, IDC_GRP_REPORT);
    hReport = mk("EDIT", "", ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL, IDC_REPORT, 0);

    hStatus = CreateWindowExA(0, STATUSCLASSNAMEA, "", WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP,
                              0, 0, 0, 0, hMain, (HMENU)(INT_PTR)IDC_STATUS, hInst, nullptr);

    // fonts
    EnumChildWindows(hMain, setFontProc, (LPARAM)fNormal);
    SendMessage(hTitle, WM_SETFONT, (WPARAM)fTitle, TRUE);
    for (int i = 0; i < 3; i++) {
        SendMessage(hCardV[i], WM_SETFONT, (WPARAM)fBig, TRUE);
        SendMessage(hCardC[i], WM_SETFONT, (WPARAM)fBold, TRUE);
    }
    SendMessage(hReport, WM_SETFONT, (WPARAM)fMono, TRUE);
    SendMessage(hBudStatus, WM_SETFONT, (WPARAM)fMono, TRUE);
    SendMessage(hAdd, WM_SETFONT, (WPARAM)fBold, TRUE);

    // start on today's month / year
    SYSTEMTIME now;
    GetLocalTime(&now);
    SendMessage(hMonth, CB_SETCURSEL, now.wMonth - 1, 0);
    SendMessage(hSpin, UDM_SETBUDDY, (WPARAM)hYear, 0);
    SendMessage(hSpin, UDM_SETPOS32, 0, now.wYear);
}

// ------------------------------------------------------------------ window procedure
static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {

    switch (msg) {

    case WM_CREATE:
        hMain = hwnd;
        createControls();
        ready = true;
        refreshAll();
        refreshBudget(true);
        setStatus("Ready.  Data folder: same folder as this program.");
        return 0;

    case WM_SIZE:
        if (hStatus && wp != SIZE_MINIMIZED) {
            SendMessage(hStatus, WM_SIZE, 0, 0);
            RECT sr;
            GetWindowRect(hStatus, &sr);
            layout(LOWORD(lp), HIWORD(lp) - (sr.bottom - sr.top));
            InvalidateRect(hwnd, nullptr, TRUE);
        }
        return 0;

    case WM_GETMINMAXINFO: {
        MINMAXINFO* mm = (MINMAXINFO*)lp;
        RECT r = {0, 0, S(1000), S(720)};
        AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
        mm->ptMinTrackSize.x = r.right - r.left;
        mm->ptMinTrackSize.y = r.bottom - r.top;
        return 0;
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(hwnd, &ps);
        COLORREF accent[3] = {COL_GREEN, COL_RED, gBalance >= 0 ? COL_BLUE : COL_RED};
        for (int i = 0; i < 3; i++) {
            FillRect(dc, &cardRect[i], brWhite);
            RECT strip = cardRect[i];
            strip.right = strip.left + S(5);
            HBRUSH b = CreateSolidBrush(accent[i]);
            FillRect(dc, &strip, b);
            DeleteObject(b);
        }
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_CTLCOLORSTATIC: {
        HDC dc = (HDC)wp;
        int id = GetDlgCtrlID((HWND)lp);
        switch (id) {
        case IDC_CARD_INC_C: case IDC_CARD_EXP_C: case IDC_CARD_BAL_C:
            SetTextColor(dc, COL_MUTED); SetBkColor(dc, RGB(255, 255, 255)); return (LRESULT)brWhite;
        case IDC_CARD_INC_V:
            SetTextColor(dc, COL_GREEN); SetBkColor(dc, RGB(255, 255, 255)); return (LRESULT)brWhite;
        case IDC_CARD_EXP_V:
            SetTextColor(dc, COL_RED); SetBkColor(dc, RGB(255, 255, 255)); return (LRESULT)brWhite;
        case IDC_CARD_BAL_V:
            SetTextColor(dc, gBalance >= 0 ? COL_BLUE : COL_RED); SetBkColor(dc, RGB(255, 255, 255));
            return (LRESULT)brWhite;
        case IDC_REPORT:
            SetTextColor(dc, COL_TEXT); SetBkColor(dc, RGB(255, 255, 255)); return (LRESULT)brWhite;
        case IDC_BUDSTATUS: {
            COLORREF c = budgetState == 3 ? COL_RED : budgetState == 2 ? COL_ORANGE
                       : budgetState == 1 ? COL_GREEN : COL_MUTED;
            SetTextColor(dc, c); SetBkColor(dc, COL_BG); return (LRESULT)brBg;
        }
        case IDC_TITLE:
            SetTextColor(dc, COL_TEXT); SetBkColor(dc, COL_BG); return (LRESULT)brBg;
        default:
            SetTextColor(dc, COL_TEXT); SetBkColor(dc, COL_BG); return (LRESULT)brBg;
        }
    }

    case WM_COMMAND: {
        int id = LOWORD(wp), code = HIWORD(wp);
        switch (id) {
        case IDC_ADD:        onAdd(); break;
        case IDC_SETBUD:     onSetBudget(); break;
        case IDC_BTN_SEARCH: refreshList(); break;
        case IDC_BTN_ALL:    SetWindowTextA(hSearch, ""); refreshList(); setStatus("Showing all transactions."); break;
        case IDC_BTN_DELETE: onDelete(); break;
        case IDC_MONTH:      if (code == CBN_SELCHANGE) refreshBudget(true); break;
        case IDC_YEAR:       if (code == EN_CHANGE && ready) refreshBudget(true); break;
        }
        return 0;
    }

    case WM_NOTIFY: {
        NMHDR* nh = (NMHDR*)lp;
        if (nh->idFrom == IDC_LIST) {

            if (nh->code == NM_CUSTOMDRAW) {
                NMLVCUSTOMDRAW* cd = (NMLVCUSTOMDRAW*)lp;
                switch (cd->nmcd.dwDrawStage) {
                case CDDS_PREPAINT:
                    return CDRF_NOTIFYITEMDRAW;
                case CDDS_ITEMPREPAINT:
                    return CDRF_NOTIFYSUBITEMDRAW;
                case CDDS_ITEMPREPAINT | CDDS_SUBITEM: {
                    Transaction* t = (Transaction*)cd->nmcd.lItemlParam;
                    if (t && (cd->iSubItem == 2 || cd->iSubItem == 4))
                        cd->clrText = t->getType() == "INCOME" ? COL_GREEN : COL_RED;
                    else
                        cd->clrText = GetSysColor(COLOR_WINDOWTEXT);
                    return CDRF_NEWFONT;
                }
                }
                return CDRF_DODEFAULT;
            }

            if (nh->code == LVN_KEYDOWN && ((NMLVKEYDOWN*)lp)->wVKey == VK_DELETE) {
                onDelete();
                return 0;
            }
        }
        return 0;
    }

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hwnd, msg, wp, lp);
}

// ------------------------------------------------------------------ entry point
int WINAPI WinMain(HINSTANCE hi, HINSTANCE, LPSTR, int nShow) {

    hInst = hi;

    INITCOMMONCONTROLSEX icc;
    icc.dwSize = sizeof icc;
    icc.dwICC = ICC_WIN95_CLASSES | ICC_DATE_CLASSES | ICC_STANDARD_CLASSES | ICC_UPDOWN_CLASS;
    InitCommonControlsEx(&icc);

    HDC sdc = GetDC(nullptr);
    dpi = GetDeviceCaps(sdc, LOGPIXELSX);
    ReleaseDC(nullptr, sdc);

    fNormal = mkFont(9, FW_NORMAL);
    fBold   = mkFont(9, FW_SEMIBOLD);
    fTitle  = mkFont(20, FW_BOLD);
    fBig    = mkFont(17, FW_BOLD);
    fMono   = mkFont(10, FW_NORMAL, "Consolas");
    brBg    = CreateSolidBrush(COL_BG);
    brWhite = CreateSolidBrush(RGB(255, 255, 255));

    // data files live next to the .exe (same place as your console version's files)
    char path[MAX_PATH];
    GetModuleFileNameA(nullptr, path, MAX_PATH);
    string dir(path);
    size_t slash = dir.find_last_of("\\/");
    dir = (slash == string::npos) ? "" : dir.substr(0, slash + 1);
    core = new TrackerCore(dir);

    WNDCLASSA wc;
    memset(&wc, 0, sizeof wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hi;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
    wc.hbrBackground = brBg;
    wc.lpszClassName = "ExpenseTrackerWnd";
    RegisterClassA(&wc);

    RECT r = {0, 0, S(1080), S(740)};
    AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);

    HWND hwnd = CreateWindowExA(0, wc.lpszClassName, "Personal Expense Tracker",
                                WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, CW_USEDEFAULT, CW_USEDEFAULT,
                                r.right - r.left, r.bottom - r.top, nullptr, nullptr, hi, nullptr);

    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {

        // Enter key does the natural thing for the box you are typing in
        if (msg.message == WM_KEYDOWN && msg.wParam == VK_RETURN) {
            HWND f = GetFocus();
            if (f == hSearch)                                         { refreshList(); continue; }
            if (f == hBudget)                                         { onSetBudget(); continue; }
            if (f == hAmount || f == hType || GetParent(f) == hCategory) { onAdd(); continue; }
        }

        if (!IsDialogMessage(hwnd, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    delete core;
    return (int)msg.wParam;
}
